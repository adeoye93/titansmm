<?php return array (
    'primaryColor' => 'a460f2',
    'subheading' => '204dcc',
    'bggrdleft' => '7c35ff',
    'bggrdright' => '5900ff',
    'bggrdleft2' => '8340ff',
    'btngrdleft' => 'af61f5',
    'copyrights' => '1d43db',
);
