<?php
return [
    'minimal' => [
        'title' => 'Minimal',
        'path' => 'assets/uploads/theme/minimal.png',
    ],
    'deepblue' => [
        'title' => 'Deep Blue',
        'path' => 'assets/uploads/theme/deepblue.png',
    ],
    'darkmode' => [
        'title' => 'Dark Mode',
        'path' => 'assets/uploads/theme/darkmode.png',
    ]

];
