<?php return array (
    'meta_image' => 'meta.png',
    'meta_keywords' => 'SMM Matrix, best smm panel, cheapest smm panel, facebook, follower, Indusrabbit, instagram, like, next post, seo service, SMM, smm panel, smm panel script, SMM Reseller Panel, social media marketing, youtube , subscribers',
    'meta_description' => 'SMM Matrix is an online social media marketing tool. This software includes almost everything for you need to do a social media marketing business. It has services lined up for every social media platform and hence is a very versatile platform. Be it likes, followers, views, or even general engagement or website traffic, SMM Matrix can get it all, and that too at a price that does not burn a hole in your pocket.',
    'social_title' => 'SMM Matrix is an online social media marketing tool',
    'social_description' => 'SMM Matrix is an online social media marketing tool. This software includes almost everything for you need to do a social media marketing business. It has services lined up for every social media platform and hence is a very versatile platform. Be it likes, followers, views, or even general engagement or website traffic, SMM Matrix can get it all, and that too at a price that does not burn a hole in your pocket.',
);
