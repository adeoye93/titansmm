<?php

return [
    'paginate' => 20,
];
